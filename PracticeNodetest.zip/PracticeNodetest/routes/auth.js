const express = require('express');

const User = require('../models/user');

const expValidate = require('express-validator');

const authController = require('../controllers/auth');

const router = express.Router();

router.get('/login', authController.getLogin);

router.get('/signup', authController.getSignup);

router.post('/login', authController.postLogin);

router.post('/signup',
expValidate.check('email')
.isEmail()
.withMessage('Please enter a valid email')
.custom((value, {req}) => {
   return User.findOne({ email: value })
    .then(userDoc => {
      if (userDoc) {
        return Promise.reject('Email Already Registered !');
      }
    })
}),
expValidate.check('password','**password must be atleast 5 Alphanumeric character').isLength({min: 5}).isAlphanumeric(),
expValidate.check('confirmPassword').custom((value, {req}) => {
    if(value !== req.body.password){
        throw new Error('Password not matching')
    }
    return true;
}),
authController.postSignup);

router.post('/logout',authController.postLogout);

router.get('/reset', authController.getReset);

router.post('/reset', authController.postReset);

router.get('/reset/:token', authController.getNewPassword);

router.post('/new-password',
expValidate.check('password','**password must be atleast 5 Alphanumeric character').isLength({min: 5}).isAlphanumeric(),
authController.postNewPassword);

router.get('/sendotp', authController.getVerification); 

router.post('/sendotp',
expValidate.check('mobile').isLength({min: 10, max: 10}).withMessage('Enter a 10-digit No.')
.custom((value,{req}) => {
  return User.findOne({phone: value})
  .then(userMob => {
    if(userMob){
      return Promise.reject('Mobile No. already registered');
    }
  })
})
, authController.postVerification);

router.post('/matchotp',
 expValidate.check('number').isLength({min: 10, max: 10}).withMessage('Enter a valid Mobile No. first')
,expValidate.check('otp').custom((value, {req}) => {
  if(value !== req.body.motp){
    throw new Error('Wrong OTP entered')
  }
  return true;
})
,authController.matchOTP);

module.exports = router;

function getOTP() {
    document.getElementById("otp").disabled = false;
    document.getElementById("verify").disabled = false;
    showPrompt("Enter something<br>...smart :)",function(value){
        alert(value);
    })
    // fetch('/sendotp/'+otp, {
    //     method: 'POST',
    //     headers: {
    //       'csrf-token': csrf
    //     }
    //   })
    //     .then(result => {
    //       return result.json();
    //     })
    //     .then(data => {
    //       console.log(data);
    //       productElement.parentNode.removeChild(productElement);
    //     })
    //     .catch(err => {
    //       console.log(err);
    //     });
}
mapboxgl.accessToken = 'pk.eyJ1Ijoic3dhc3RpazMwMDUiLCJhIjoiY2tiYW1rbGFvMHA5ZzJ4bzhkanZhdHN1aCJ9.z6gwp_4Wjn7OKBi6tIeP1A';
const long = 88.3639
const lat = 22.5726
var map = new mapboxgl.Map({
container: 'map',
style: 'mapbox://styles/mapbox/streets-v11',
center: [long, lat], // starting position,]
zoom: 12 // starting zoom
});

map.addControl(new mapboxgl.NavigationControl());

map.addControl(
  new mapboxgl.GeolocateControl({
  positionOptions: {
  enableHighAccuracy: true
  },
  trackUserLocation: true
  })
  );

getLatLng = () => {
    fetch('/points')
      .then(result => {
        return result.json();
      })
      .then((data) => {
console.log(data);

          const points = data.map(p => {
            return {
              coordinates: [p.location.coordinates[0], p.location.coordinates[1]],
              title: p.title,
              id: p._id,
              imageUrl: p.imageUrl,
              address: p.description
            };
          });
          loadMap(points);
      })
      .catch(err => {
        console.log(err);
      });
  };

 

  function loadMap(coords) {
    function addMarker(points) {

      var el = document.createElement('div');
      el.className = 'marker';

      var marker = new mapboxgl.Marker(el)
      .setLngLat(points.coordinates)
      .setPopup(new mapboxgl.Popup()
      .setHTML(
        `<head>
        <link rel="stylesheet" href="/css/main.css">
        <link rel="stylesheet" href="/css/product.css">
        </head>
        
        <body>
        <div class="grid">
        <article class="card product-item">
        <header class="card__header">
            <h1 class="product__title">${points.title}</h1>
        </header>
        <div class="card__image">
            <img src="/${points.imageUrl}"
                alt="">
        </div>
        <div class="card__content">
    
            <p class="product__description">${points.address}</p>
          </div>
        <div class="card__actions">
            <a class="btn" href="/product/${points.id}">Details</a>
        </div>
        </article>
        </div>
        </body>
        `
        ))
      .addTo(map);
    }
    map.on('load', function() {
      for(var i = 0;i < coords.length;i++){
        addMarker(coords[i]);
      }
    });
  }
  getLatLng();
  